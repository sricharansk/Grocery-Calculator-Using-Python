IP_ADDRESS = "127.0.0.1"
PORT_NUMBER = 8888


# prices of the fruits
PRICES = {
    'apple': 35,
    'banana': 15,
    'orange': 10,
    'strawberry': 28
}
